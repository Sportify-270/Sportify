
        function showForm(formId) {
            document.getElementById('loginForm').classList.remove('visible');
            document.getElementById('clientForm').classList.remove('visible');
            document.getElementById('specialistForm').classList.remove('visible');
            document.getElementById('adminForm').classList.remove('visible');
            document.getElementById(formId).classList.add('visible');
        }

        function validateLoginForm() {
            var loginType = document.getElementById('loginType').value;
            var login = document.getElementById('login').value;
            var password = document.getElementById('password').value;
            var loginError = document.getElementById('loginError');
            
            if (login === "" || password === "") {
                loginError.textContent = "Tous les champs sont obligatoires.";
                return false;
            }
            loginError.textContent = "";
            alert("Connexion réussie en tant que " + loginType + "!");
            return true;
        }

        function validateClientForm() {
            var nom = document.getElementById('clientNom').value;
            var prenom = document.getElementById('clientPrenom').value;
            var adresse = document.getElementById('clientAdresse').value;
            var ville = document.getElementById('clientVille').value;
            var cdp = document.getElementById('clientCdp').value;
            var pays = document.getElementById('clientPays').value;
            var mail = document.getElementById('clientMail').value;
            var carte = document.getElementById('clientCarte').files.length;
            var telephone = document.getElementById('clientTelephone').value;
            var conditions = document.getElementById('clientConditions').checked;
            var clientError = document.getElementById('clientError');
            
            if (nom === "" || prenom === "" || adresse === "" || ville === "" || cdp === "" || pays === "" || mail === "" || carte === 0 || telephone === "" || !conditions) {
                clientError.textContent = "Tous les champs sont obligatoires et les conditions doivent être acceptées.";
                return false;
            }
            clientError.textContent = "";
            alert("Compte client créé avec succès!");
            return true;
        }

        function validateSpecialistForm() {
            var nom = document.getElementById('specialistNom').value;
            var prenom = document.getElementById('specialistPrenom').value;
            var photo = document.getElementById('specialistPhoto').files.length;
            var cv = document.getElementById('specialistCv').files.length;
            var telephone = document.getElementById('specialistTelephone').value;
            var mail = document.getElementById('specialistMail').value;
            var specialite = document.getElementById('specialistSpecialite').value;
            var specialistError = document.getElementById('specialistError');
            
            if (nom === "" || prenom === "" || photo === 0 || cv === 0 || telephone === "" || mail === "" || specialite === "") {
                specialistError.textContent = "Tous les champs sont obligatoires.";
                return false;
            }
            specialistError.textContent = "";
            alert("Compte spécialiste créé avec succès!");
            return true;
        }

        function validateAdminForm() {
            var nom = document.getElementById('adminNom').value;
            var prenom = document.getElementById('adminPrenom').value;
            var mail = document.getElementById('adminMail').value;
            var adminError = document.getElementById('adminError');
            
            if (nom === "" || prenom === "" || mail === "") {
                adminError.textContent = "Tous les champs sont obligatoires.";
                return false;
            }
            adminError.textContent = "";
            alert("Compte administrateur créé avec succès!");
            return true;
        }